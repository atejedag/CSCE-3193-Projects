// Abraham Tejeda 10/04/2021, Assignment 4

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Brick extends Sprite
{
	static BufferedImage image = null;
	Model model;

	public Brick(Model m)
	{
		x = 400;
		y = 300;
		w = 200;
		h = 100;
		loadImage();
		model = m;
	}

	public Brick(int x1, int y1, Model m)
	{
		x = x1;
		y = y1;
		w = 10;
		h = 10;
		loadImage();
		model = m;
	}
	
	public Brick(int x1, int y1, int w1, int h1, Model m)
	{
		x = x1;
		y = y1;
		w = w1;
		h = h1;
		loadImage();
		model = m;
	}
	
	public Brick(int x1, int y1, Model m, int coins)
	{
		x = x1;
		y = y1;
		w = 10;
		h = 10;
		loadImage();
		model = m;
	}
	
	// get brick coords from json
	public Brick(Json ob, Model m)
	{
		h = (int)ob.getLong("h");
		w = (int)ob.getLong("w");
		y = (int)ob.getLong("y");
		x = (int)ob.getLong("x");
		loadImage();
		model = m;
	}
	
	// to do ADD BRICK
	void loadImage()
	{
		if(image == null)
			image = View.loadImage("brick.png");
			
	}
	
	// adds other corner of brick and allow it to make brick from left to right
	public void endBrick(int x2, int y2)
	{
		w = Math.abs(x2 - x);
		h = Math.abs(y2 - y);
		if (x2 < x)
		{
			x = x2;
		}
		if (y2 < y)
		{
			y = y2;
		}
	}
	
	boolean update()
	{
		return true;
	}
	
	
	// unmarshalling
		void unmarshal(Json ob)
		{
			 x = (int)ob.getLong("x");
			 y = (int)ob.getLong("y");
			 w = (int)ob.getLong("w");
			 h = (int)ob.getLong("h");
		}
	
	// Marshaling
	Json marshal()
	{
		Json ob = Json.newObject();
	    ob.add("x", x);
	    ob.add("y", y);
	    ob.add("w", w);
	    ob.add("h", h);
	    return ob;
	}
	
	@Override
	public String toString() // prints location of bricks
	{
		return "Brick located at (" + x + ", " + y + ") with a width =" + w + " and a height=" + h;
	}
	
	void draw(Graphics g)
	{
		g.drawImage(image, x - model.mario.x + model.mario.marioScreenLocation, y, w, h, null); // x is world location of brick, mariox is camerapos, marioscreenlocat offset thingy
	}
	
	@Override
	boolean isBrick()
	{
		return true;
	}

	
	
}