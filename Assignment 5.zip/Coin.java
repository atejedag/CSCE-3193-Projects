import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.util.Random;

public class Coin extends Sprite 
{
	static BufferedImage coinImage = null;
	Model model;
	int horizontalVel, verticalVel;
	
	Random rand = new Random();
	
	public Coin(Sprite s, Model m)
	{
		x = s.x + 10;
		y = s.y - 10;
		w = 80;
		h = 80;
		loadImage();
		model = m;
		
		verticalVel = -30;
		int num = rand.nextInt((20 - 1) + 1) + 1; // random number between 20 and 1
		horizontalVel = num;
	}
	
	boolean update()
	{
		verticalVel += 4; // this gravity multiplier
		y += verticalVel;
		x += horizontalVel;
		
		if(this.y > 600)
			return false;
		return true;
	}
	
	void loadImage()
	{
		if(coinImage == null)
			coinImage = View.loadImage("coin.png");
	}
	
	void draw(Graphics g)
	{
		g.drawImage(coinImage, x - model.mario.x + model.mario.marioScreenLocation, y, w, h, null);
	}
	
	@Override
	boolean isCoin()
	{
		return true;
	}
	
}
