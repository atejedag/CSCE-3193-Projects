// Abraham Tejeda 10/04/2021, Assignment 4

import java.awt.Graphics;
import java.awt.image.BufferedImage;


public class Mario extends Sprite{
	int px, py;
	
	float vertVelocity;
	static BufferedImage[] images = null; // make this array for assignment
	int framesSinceSolid;
	int imageNum;	
	int marioScreenLocation;
	boolean marioSideColliding; // for background

	
	public Mario() // initialize stuff
	{
		marioScreenLocation = 150;
		x = 0;
		y = 0;
		w = 60;
		h = 95;
		vertVelocity = 0;
		framesSinceSolid = 0;
		imageNum = 4;
		
		if(images == null)
		{
			images = new BufferedImage[5];
			images[0] = View.loadImage("mario.png");	
			images[1] = View.loadImage("mario2.png");	
			images[2] = View.loadImage("mario3.png");	
			images[3] = View.loadImage("mario4.png");	
			images[4] = View.loadImage("mario5.png");	
			// System.out.println("IMAGES LOADED"); // debug statement
		}
		
	}
	
	
	
	boolean update()
	{
		vertVelocity += 2.1; // this gravity multiplier
		y += vertVelocity; // update pos
		 
		framesSinceSolid += 1; // increment for every frame off ground
		
		if(y > 400)
		{
			vertVelocity = 0; // stops mario
			y = 400;
		}
		
		if(vertVelocity == 0) // if mario is on solid ground, set variable that lets him jump
			framesSinceSolid = 0;
		
		return true;
	}
	
	void updateImageNum() // updates mario sprite to animate him
	{
		imageNum++;
		if(imageNum > 4)
		{
			imageNum = 0;
		}
	}
	
	
	int getOutOfOb(Sprite s) // prevent collision with bricks and other stuf
	{
		if(this.x + this.w >= s.x && this.px + this.w <= s.x) // right side collision
			this.x = s.x - this.w;
		
		if(this.x <= s.x + s.w && this.px >= s.x + s.w) // left side collision
			this.x = s.x + s.w;
		
		if(this.y + this.h >= s.y && this.py + this.h <= s.y) // bottom collision
		{
			this.vertVelocity = 0;
			this.framesSinceSolid = 0;
			this.y = s.y - this.h;
		}
		if(this.y <= s.y + s.h && this.py >= s.y + s.h) // top collision
		{
			this.y = s.y + s.h;
			vertVelocity = 10;
			return 1;
		}
		return 0;
	}
	
	
	
	@Override
	public String toString() // prints location of bricks
	{
		return "Mario located at (" + x + ", " + y + ") with a width =" + w + " and a height=" + h;
	}
	
	
	
	public void jump()
	{
		if(framesSinceSolid < 5) // frames to detect how long in air so you can hold jump to jump higher and not be able to jump midair
		{
			vertVelocity -= 7.5;
		}
	}
	
	@Override
	void draw(Graphics g) // draws maro, int n to choose image from array
	{
		g.drawImage(images[imageNum], marioScreenLocation, y, null); // x is world location, mario.x is camera, screenLoc is offset to move him away from very edge of screen
	}
	
	void savePrevCoords() // saves previous coords to help in collision
	{
		px = x;
		py = y;
	}
	
	@Override
	boolean isMario() // keep maro updating
	{
		return true;
	}
	
	
	
}
// 