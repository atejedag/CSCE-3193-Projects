// Abraham Tejeda 10/04/2021, Assignment 4

import java.util.ArrayList;


class Model
{
	ArrayList<Sprite> sprites;
	Mario mario;
	coinBlock coinBlock1;
	coinBlock coinBlock2;
	coinBlock coinBlock3;
	
	
	Model()
	{
		sprites = new ArrayList<Sprite>(30);
		mario = new Mario();
		sprites.add(mario);
		Json j = Json.load("map.json");
		unmarshal(j);
		System.out.println("Map loaded");
	}
	
	
	
	public void update() // updates mario and collisions
	{
		for(int i = 0; i < sprites.size(); i++)
		{
			// System.out.println(sprites.size()); debug adding/removing sprites from array
			if(!sprites.get(i).update())
			{
				if(sprites.get(i).iscoinBlock()) // if sprite that has stopped updating is a coinBlock, replace it with brick
				{
					int x = sprites.get(i).x;
					int y = sprites.get(i).y;
					sprites.set(i, new Brick(x,y,100,100,this));
				}
				else // remove for every other sprite
					sprites.remove(i);
			}
			
			else if(sprites.get(i).isBrick()) // collision for bricks
			{
				if(mario.checkCollision(sprites.get(i)))
					mario.getOutOfOb(sprites.get(i));
			}
			
			else if(sprites.get(i).iscoinBlock()) // collision for coin blocks
			{
				if(mario.checkCollision(sprites.get(i)))
				{
					if(mario.getOutOfOb(sprites.get(i)) == 1) // prevents going inside coin blocks and checks if hitting bottom for coins
					{
						sprites.add(sprites.size(), new Coin(sprites.get(i), this)); // add coin sprite to array
						sprites.get(i).coinCounter -= 1; // reduce amount of coins by 1 until all 5 are gone to signal to stop updating
					}
				}
			}   
			
		}
	}
	
	
	
	// Marshals this object into a JSON DOM
	  Json marshal()
	  {
	      Json ob = Json.newObject();
	      Json tmpList = Json.newList();
	      ob.add("bricks", tmpList);
	      for(int i = 0; i < sprites.size(); i++)
	      {
	    	  Sprite s = sprites.get(i);
	    	  if(s.isBrick())
	    	  {
	    		  Brick b = (Brick)s;
	    		  tmpList.add(b.marshal());
	    	  }
	      }
	      return ob;
	  }
	  
	  
	  
	// unmarshall idk
		void unmarshal(Json ob)
		{
		    sprites = new ArrayList<Sprite>();
		    mario = new Mario();
		    sprites.add(mario);
		    
		    // hard code coin bricks in
		    coinBlock1 = new coinBlock(600, 100, this, 5); // x,y,model,#ofCoins
		    coinBlock2 = new coinBlock(100, 150, this, 5);
		    coinBlock3 = new coinBlock(900, 250, this, 5);
		    sprites.add(coinBlock1);
		    sprites.add(coinBlock2);
		    sprites.add(coinBlock3);
		    
		    Json tmpList = ob.get("bricks");
		    for(int i = 0; i < tmpList.size(); i++)
		        sprites.add(new Brick(tmpList.get(i), this));
		}
	  
	  
	  
}