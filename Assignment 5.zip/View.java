// Abraham Tejeda 10/04/2021, Assignment 4

import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import javax.imageio.ImageIO;
import java.io.IOException;
import java.io.File;
import java.awt.Color;
import java.awt.Graphics;


class View extends JPanel
{
	Model model;
	Model mario;
	BufferedImage background;
	public int backgroundX = -100;
	

	View(Controller c, Model m) // initialize
	{
		c.setView(this);
		model = m;
		background = loadImage("background.png"); // load the background
	}
	
	
	
	static BufferedImage loadImage(String filename) // load images
	{
		BufferedImage im = null;
		try
		{
			im = ImageIO.read(new File(filename));
			System.out.println(filename + " loaded.");
		} catch(Exception e) {
			e.printStackTrace(System.err);
			System.exit(1);
		}
		return im;
	}

	
	
	public void paintComponent(Graphics g)
	{
		// draw background color
		g.setColor(new Color(128, 255, 255));
		g.fillRect(0, 0, this.getWidth(), this.getHeight());
		
		// draws background clouds and stuff
		g.drawImage(background, backgroundX,0, null);
		
		// draw simple ground
		g.setColor(Color.gray);
		g.fillRect(0, 496, 2000, 496);
		
		// draw sprites
		for(int i = 0; i < model.sprites.size(); i++)
		{
			Sprite s = model.sprites.get(i);
			s.draw(g);
		}
		// System.out.println(model.mario + "\n"); // prints out coordinates
		
	}
	
}
