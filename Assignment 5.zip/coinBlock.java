import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class coinBlock extends Sprite
{
	static BufferedImage blockImage = null;
	Model model;
	
	public coinBlock(int x1, int y1, Model m, int numCoins) // set coin block position and number of coins
	{
		x = x1;
		y = y1;
		w = 100;
		h = 100;
		loadImage();
		model = m;
		coinCounter = numCoins;
	}
	
	void loadImage()
	{
		if(blockImage == null)
			blockImage = View.loadImage("coinBlock.png");
	}
	
	
	boolean update()
	{
		if(coinCounter == 0) // remove coin block when no more coins
			return false;
		return true;
	}
	
	void draw(Graphics g)
	{
		g.drawImage(blockImage, x - model.mario.x + model.mario.marioScreenLocation, y, w, h, null);
	}
	
	@Override
	boolean iscoinBlock()
	{
		return true;
	}
	
	
}

