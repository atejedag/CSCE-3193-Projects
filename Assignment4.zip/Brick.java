// Abraham Tejeda 10/04/2021, Assignment 4

import java.awt.Graphics;
import java.awt.image.BufferedImage;

public class Brick
{
	int x;
	int y;
	int w;
	int h;
	static BufferedImage image = null;

	public Brick()
	{
		x = 400;
		y = 300;
		w = 200;
		h = 100;
		loadImage();
	}

	public Brick(int x1, int y1)
	{
		x = x1;
		y = y1;
		w = 10;
		h = 10;
		loadImage();
	}
	
	public Brick(int x1, int y1, int w1, int h1)
	{
		x = x1;
		y = y1;
		w = w1;
		h = h1;
		loadImage();
	}
	
	// get brick coords from json
	public Brick(Json ob)
	{
		h = (int)ob.getLong("h");
		w = (int)ob.getLong("w");
		y = (int)ob.getLong("y");
		x = (int)ob.getLong("x");
		loadImage();
	}
	
	// to do ADD BRICK
	void loadImage()
	{
		if(image == null)
			image = View.loadImage("brick.png");
	}
	
	// adds other corner of brick and allow it to make brick from left to right
	public void endBrick(int x2, int y2)
	{
		w = Math.abs(x2 - x);
		h = Math.abs(y2 - y);
		if (x2 < x)
		{
			x = x2;
		}
		if (y2 < y)
		{
			y = y2;
		}
	}
	
	void update()
	{
		
	}
	
	
	// unmarshalling
		void unmarshal(Json ob)
		{
			 x = (int)ob.getLong("x");
			 y = (int)ob.getLong("y");
			 w = (int)ob.getLong("w");
			 h = (int)ob.getLong("h");
		}
	
	// Marshaling
	Json marshal()
	{
		Json ob = Json.newObject();
	    ob.add("x", x);
	    ob.add("y", y);
	    ob.add("w", w);
	    ob.add("h", h);
	    return ob;
	}
	
	@Override
	public String toString() // prints location of bricks
	{
		return "Brick located at (" + x + ", " + y + ") with a width =" + w + " and a height=" + h;
	}
	
	void draw(Graphics g, int marioScreenLocation)
	{
		g.drawImage(image, x - Mario.x + marioScreenLocation, y, w, h, null); // x is world location of brick, mariox is camerapos, marioscreenlocat offset thingy
	}
	
	
}