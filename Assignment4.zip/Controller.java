// Abraham Tejeda 10/04/2021, Assignment 4

import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.event.ActionListener;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.KeyListener;
import java.awt.event.KeyEvent;


class Controller implements MouseListener, KeyListener
{
	View view;
	Model model;
	Mario mario;
	boolean keyLeft;
	boolean keyRight;
	boolean keyUp;
	boolean keyDown;
	boolean keySpace;
	Brick b;
	boolean edit = false;

	Controller(Model m)
	{
		model = m;
	}

	

	void setView(View v)
	{
		view = v;
	}

	
	
	// records brick's corner
	public void mousePressed(MouseEvent e)
	{
		if(edit == true)
			b = new Brick(e.getX() + Mario.x - model.mario.marioScreenLocation, e.getY());
	}

	
	
	// records other corner of brick
	public void mouseReleased(MouseEvent e) { 
		if(edit == true)
		{
			b.endBrick(e.getX() + Mario.x - model.mario.marioScreenLocation, e.getY());
			model.bricks.add(b);
		}
		
		
	}
	
	
	
	public void mouseEntered(MouseEvent e) {   }
	
	
	
	public void mouseExited(MouseEvent e) {    }
	
	
	
	public void mouseClicked(MouseEvent e) 
	{  
		if(e.getY() < 100)
		{
			System.out.println("break here");
		}
	}
	
	

	public void keyPressed(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_RIGHT: 
				keyRight = true; 
				
				break;
			case KeyEvent.VK_LEFT: 
				keyLeft = true; 
				
				break;
			case KeyEvent.VK_UP: keyUp = true; break;
			case KeyEvent.VK_DOWN: keyDown = true; break;
			case KeyEvent.VK_SPACE: keySpace = true;
		}
				
	}
	
	

	// keys that do stuff
	public void keyReleased(KeyEvent e)
	{
		switch(e.getKeyCode())
		{
			case KeyEvent.VK_RIGHT: keyRight = false; break;
			case KeyEvent.VK_LEFT: keyLeft = false; break;
			case KeyEvent.VK_UP: keyUp = false; break;
			case KeyEvent.VK_DOWN: keyDown = false; break;
			case KeyEvent.VK_SPACE: keySpace = false; break;
			case KeyEvent.VK_ESCAPE: System.out.println("Exiting now..."); System.exit(0); break;
		}
		char c = e.getKeyChar();
		if(c == 's' || c == 'S') // save map
		{
			model.marshal().save("map.json");
			System.out.println("Map has been saved to map.json");
		}
		if(c == 'l' || c == 'L') // load saved map
		{
			Json j = Json.load("map.json");
			model.unmarshal(j);
			System.out.println("Loaded map.json");
		}
		if(c == 'q' || c == 'Q') // quit application
		{
			System.out.println("Exitting now..");
			System.exit(0);
		}
		if(c == 'e' || c == 'E') // toggle edit mode to add bricks with mouse
		{
			edit = !edit;
			System.out.println("Edit mode: " + edit);
		}
	}

	
	
	public void keyTyped(KeyEvent e)
	{
	}
	
	

	// update camera position when moving left to right
	void update()
	{
		if(keyRight) // move mario/background
		{
			model.mario.x += 10;
			model.mario.updateImageNum();
			view.backgroundX -= 5;
		}
		if(keyLeft) // move mario/background
		{
			model.mario.x -= 10;
			model.mario.updateImageNum();
			view.backgroundX += 5;
		}
		if(keySpace) // mario jumpin'
			model.mario.jump();
	}
}
