// Abraham Tejeda 10/04/2021, Assignment 4

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.Iterator;


class Mario {
	static int x; //
	int y;
	final int w = 60;
	final int h = 95;
	float vertVelocity;
	static BufferedImage[] images = null; // make this array for assignment
	int framesSinceSolid;
	int imageNum;	
	int marioScreenLocation;
	boolean marioSideColliding; // for background

	
	public Mario() // initialize stuff
	{
		marioScreenLocation = 150;
		x = 0;
		y = 0;
		vertVelocity = 0;
		framesSinceSolid = 0;
		imageNum = 4;
		
		if(images == null)
		{
			images = new BufferedImage[5];
			images[0] = View.loadImage("mario.png");	
			images[1] = View.loadImage("mario2.png");	
			images[2] = View.loadImage("mario3.png");	
			images[3] = View.loadImage("mario4.png");	
			images[4] = View.loadImage("mario5.png");	
			// System.out.println("IMAGES LOADED"); // debug statement
		}
		
	}
	
	
	
	public void update()
	{
		vertVelocity += 2.1; // this gravity multiplier
		y += vertVelocity; // update pos
		 
		framesSinceSolid += 1; // increment for every frame off ground
		
		if(y > 400)
		{
			vertVelocity = 0; // stops mario
			y = 400;
		}
		if(vertVelocity == 0)
			framesSinceSolid = 0;
		
	}
	
	void updateImageNum() // using INTERATOR
	{
		imageNum++;
		if(imageNum > 4)
		{
			imageNum = 0;
		}
	}
	
	void getOutOfBrick(Brick b) // prevent collision
	{
		int mRight = x + w, mLeft = x, mTop = y, mBottom = y+h; // set variables marios sides
		int bRight = b.x + b.w, bLeft = b.x, bTop = b.y, bBottom = b.y+b.h; // set variables for bricks sides
		
		if((mTop <= bBottom) && (mBottom > bBottom) && (mLeft > (bLeft - 45)) && (mRight < (bRight + 45))) // hit head with brick
		{
			y = b.y + b.h;
			vertVelocity = 0; // hitting head on top kinda weird
		}
		else if((mBottom >= bTop) && (mTop <= bTop) && (mLeft > bLeft - 45) && (mRight < (bRight + 45))) // stand on brick, adjustments to bLeft/Right to make it so mario doesn't slip off as easily
		{
			y = b.y - h; 
			vertVelocity = 0;
			framesSinceSolid = 0; // allow user to jump on bricks
		}
		
		else if((mRight >= bLeft) && (mLeft <= bLeft) && ((mBottom - 5) >= bTop) && ((mTop + 5) <= bBottom)) // maro right side touching, minor adjustments just in case
			x = bLeft - w;
				
			
		else if((mLeft <= bRight) && (mRight >= bRight) && ((mBottom + 5) >= bTop) && ((mTop -5) <= bBottom)) // maro left side touching, minor adjustments just in case
			x = bRight;
	}
	
	
	@Override
	public String toString() // prints location of bricks
	{
		return "Mario located at (" + x + ", " + y + ") with a width =" + w + " and a height=" + h;
	}
	
	
	
	public void jump()
	{
		if(framesSinceSolid < 5) // frames to detect how long in air so you can hold jump to jump higher and not be able to jump midair
		{
			vertVelocity -= 7.5;
		}
	}
	
	
	void draw(Graphics g) // draws maro, int n to choose image from array
	{
		g.drawImage(images[imageNum], x - Mario.x + marioScreenLocation, y, null); // x is world location, mario.x is camera, screenLoc is offset to move him away from very edge of screen
	}
	
	
	
	
}
// 