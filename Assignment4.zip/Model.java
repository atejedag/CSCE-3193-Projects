// Abraham Tejeda 10/04/2021, Assignment 4

import java.util.ArrayList;

class Model
{
	ArrayList<Brick> bricks;
	Mario mario;

	
	
	Model()
	{
		bricks = new ArrayList<Brick>();
		mario = new Mario();
		Json j = Json.load("map.json");
		unmarshal(j);
		System.out.println("Map loaded");
	}
	
	
	
	public void update() // updates mario and collisions
	{
		mario.update();
		checkCollisions();
	}
	
	void checkCollisions()
	{
		for(int i = 0; i < bricks.size(); i++)
		{
			 Brick b = bricks.get(i);
			 if(marioIsColliding(b))
			 {
				 // System.out.println("IM COLLIDING");
				 // System.out.println(b);
				 mario.getOutOfBrick(b); // function to find what side mario is on to go and not get him stuck in the bricks
			 }
			 
			 
		}
	}
	
	boolean marioIsColliding(Brick b)
	{
		if(mario.x + mario.w < b.x)
			return false;
		if(mario.x > b.x + b.w)
			return false;
		
		return true;
	}
	
	
	
	
	// Marshals this object into a JSON DOM
	  Json marshal()
	  {
	      Json ob = Json.newObject();
	      Json tmpList = Json.newList();
	      ob.add("bricks", tmpList);
	      for(int i = 0; i < bricks.size(); i++)
	    	  tmpList.add(bricks.get(i).marshal());
	      return ob;
	  }
	  
	  
	  
	// unmarshall idk
		void unmarshal(Json ob)
		{
		    bricks = new ArrayList<Brick>();
		    Json tmpList = ob.get("bricks");
		    for(int i = 0; i < tmpList.size(); i++)
		        bricks.add(new Brick(tmpList.get(i)));
		}
	  
	  
	  
}