# Abraham Tejeda Granados 12/09/2021, Assignment 8 Mario in Python 
import pygame
import time
import random

from pygame.locals import*
from time import sleep

class Sprite():
    def __init__(self, x, y, w, h):
        self.x = x
        self.y = y
        self.w = w
        self.h = h

    def checkCollision(self, s):
        if(self.x + self.w <= s.x): # mario's right and s left
            return False
        if(self.x > s.x + s.w): # mario's left and s right
            return False
        if(self.y + self.h <= s.y): # mario's bottom and s top
            return False
        if(self.y >= s.y + s.h): # mario's top and s bottom
            return False
        return True


class Mario(Sprite):
    def __init__(self):
        super().__init__(0, 0, 60, 95) # super extended from Sprite Class
        self.marioScreenLocation = 150
        self.vertVelocity = 0
        self.framesSinceSolid = 0
        self.px = 0
        self.py = 0
        self.imageNum = 0 # tracks image number for array
        #load all images into variable
        self.marioImage1 = pygame.image.load("mario.png")
        self.marioImage2 = pygame.image.load("mario2.png")
        self.marioImage3 = pygame.image.load("mario3.png")
        self.marioImage4 = pygame.image.load("mario4.png")
        self.marioImage5 = pygame.image.load("mario5.png")
        # mario's array of images to cycle through
        self.marioImages = [self.marioImage1, self.marioImage2, self.marioImage3, self.marioImage4,self.marioImage5]
        self.whatIsIt = 0 # number 0 coorelates to mario


    def update(self):
        self.vertVelocity += 2.1
        self.y += self.vertVelocity # set vertical velocity/gravity for mario

        self.framesSinceSolid += 1 # when in the air, count frames that mario is in the air

        if self.y > 400: # when mario is on the ground
            self.vertVelocity = 0
            self.y = 400

        if self.vertVelocity == 0: # when mario isn't going down, reset framessincesolid to 0
            self.framesSinceSolid = 0

        return True

    def jump(self): # maro jumps
        if(self.framesSinceSolid < 5):
            self.vertVelocity -= 7.5

    def updateImage(self): # goes through mario images when walking
        self.imageNum = self.imageNum + 1
        if(self.imageNum > 4):
            self.imageNum = 0

    def draw(self, screen): # draw mario to screen
        screen.blit(self.marioImages[self.imageNum],(self.marioScreenLocation,self.y))

    def savePrevCoords(self): # saves previous coordinates to use for getOutOfObj method
        self.px = self.x
        self.py = self.y

    def getOutOfObj(self, s): # get mario out of sprite s
        if self.x + self.w >= s.x and self.px + self.w <= s.x: # right side collide
            self.x = s.x - self.w
        if self.x <= s.x + s.w and self.px >= s.x + s.w: # left side collide
            self.x = s.x + s.w
        if self.y + self.h >= s.y and self.py + self.h <= s.y: # bottom collide
            self.vertVelocity = 0 # set variables to make game think mario is on ground so he can jump normally
            self.framesSinceSolid = 0
            self.y = s.y - self.h
        if self.y <= s.y + s.h and self.py >= s.y + s.h: # top collide
            self.y = s.y + s.h
            self.vertVelocity = 5 # when collding, knock mario down to prevent it hitting block multiple times for coinblock
            return 1
        return 0


class Brick(Sprite):
    def __init__(self, model, x, y ,w, h):
        super().__init__(x, y, w, h)
        self.model = model
        self.image = pygame.image.load("brick.png")
        self.image = pygame.transform.scale(self.image, (w, h)) # resize image
        self.whatIsIt = 1 # number 1 correlates to brick

    def update(self):
        return True

    def draw(self, screen):
        screen.blit(self.image, (self.x - self.model.mario.x + self.model.mario.marioScreenLocation, self.y, self.w, self.h))

class coinBlock(Sprite):
    def __init__(self, model, x, y, w, h):
        super().__init__(x, y, w, h)
        self.coinCounter = 5 # number of coins in coinBlock, will decrement when mario hits bottom of block
        self.model = model
        self.image = pygame.image.load("coinBlock.png")
        self.image = pygame.transform.scale(self.image, (w, h))
        self.whatIsIt = 2 # 2 coorelates to coinBlock

    def update(self):
        if self.coinCounter == 0: # stop updating coinblock when no more coins
            return False
        return True

    def draw(self, screen):
        screen.blit(self.image, (self.x - self.model.mario.x + self.model.mario.marioScreenLocation, self.y, self.w, self.h))

class coin(Sprite):
    def __init__(self, model, s):
        super().__init__(s.x + 10, s.y - 10, 80, 80)
        self.model = model
        self.image = pygame.image.load("coin.png")
        self.image = pygame.transform.scale(self.image, (self.w, self.h))
        self.verticalVel = -30 # initial high vertical velocity to launch coin up when it appears
        self.randomNum = random.randint(2, 20) # set horizontal velocity with random speed between 2 and 20
        self.horizontalVel = self.randomNum
        self.whatIsIt = 3 # 3 coorelates to coin, not needed but called in i.whatIsIt check so just give it a value


    def update(self):
        self.verticalVel += 4
        self.y += self.verticalVel
        self.x += self.horizontalVel

        if(self.y > 600):
            return False
        return True

    def draw(self, screen):
        screen.blit(self.image, (self.x - self.model.mario.x + self.model.mario.marioScreenLocation, self.y, self.w, self.h))


class Model():
    def __init__(self):
        self.spritesArray = []
        self.mario = Mario()
        self.background = pygame.image.load("background.png")
        self.backgroundX = 0

        # hard code all sprites into the array
        self.spritesArray.append(self.mario)
        self.spritesArray.append(coinBlock(self, 200,150,75,75))
        self.spritesArray.append(coinBlock(self, 700, 100, 75, 75))
        self.spritesArray.append(Brick(self, 200, 420, 75, 75))
        self.spritesArray.append(Brick(self, 500, 320, 75, 100))
        self.spritesArray.append(Brick(self, -150, 420, 125, 75))
        self.spritesArray.append(Brick(self, 575, 420, 80, 80))
    def update(self):
        for i in self.spritesArray:
            if i.update() != True:
                if(i.whatIsIt == 2): # if its a coinBlock that stops updating, replace with brick
                    self.spritesArray.append(Brick(self, i.x, i.y, i.w, i.h))
                    self.spritesArray.remove(i)
                else:
                    self.spritesArray.remove(i)
            elif i.whatIsIt == 1: # if its a brick
                if self.mario.checkCollision(i): # detect and prevent collision of bricks
                    self.mario.getOutOfObj(i)
            elif i.whatIsIt == 2: # if its a coinblock
                if self.mario.checkCollision(i): # detect and prevent collison of coinblcoks AND know when to get coins
                    if self.mario.getOutOfObj(i) == 1:
                        self.spritesArray.append(coin(self, i)) # adds coins
                        i.coinCounter -= 1 # decrement coinblock's coins
                                                 
            
                



class View():
    def __init__(self, model):
        screen_size = (800,600)
        self.screen = pygame.display.set_mode(screen_size, 32)
        self.model = model
        


    def update(self):
        self.screen.fill([100,100,100])
        self.screen.blit(self.model.background, (self.model.backgroundX, -75))
        pygame.draw.rect(self.screen, (210, 180, 140), (0,495,2000,125)) # ground box
        for i in self.model.spritesArray: # for loop to re draw each sprite to screen
            i.draw(self.screen)
        pygame.display.flip()




class Controller():
    def __init__(self, model):
        self.model = model
        self.keep_going = True


    def update(self):
        self.model.mario.savePrevCoords()
        for event in pygame.event.get():
            if event.type == QUIT:
                self.keep_going = False
            elif event.type == KEYDOWN:
                if event.key == K_ESCAPE:
                    self.keep_going = False
        keys = pygame.key.get_pressed()
        if keys[K_LEFT]: # move left
            self.model.mario.x -= 10
            self.model.backgroundX += 5
            self.model.mario.updateImage()
        if keys[K_RIGHT]: # move right
            self.model.mario.x += 10
            self.model.backgroundX -= 5
            self.model.mario.updateImage()
        if keys[K_SPACE]: # maro do the jump
            self.model.mario.jump()
            

#main game stuff
pygame.init()
m = Model()
v = View(m)
c = Controller(m)
while c.keep_going:
    c.update()
    m.update()
    v.update()
    sleep(0.04)
print("quitting")
pygame.display.quit()
pygame.quit()
